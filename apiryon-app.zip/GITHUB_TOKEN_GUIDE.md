# 🔑 יצירת GitHub Personal Access Token - מדריך מפורט

## למה אני צריך את זה?

GitHub **לא מאפשר** יותר להעלות קוד עם סיסמה רגילה.  
צריך **Personal Access Token** (PAT) - זה כמו סיסמה מיוחדת לקוד.

---

## 📋 המדריך (5 דקות):

### שלב 1: פתח את דף יצירת ה-Token

לחץ כאן: 👉 **https://github.com/settings/tokens/new**

או:
1. GitHub → הצד שלך למעלה
2. Settings
3. Developer settings (בסוף הרשימה)
4. Personal access tokens → Tokens (classic)
5. Generate new token

---

### שלב 2: תראה טופס כזה

```
┌───────────────────────────────────────────┐
│ New personal access token                 │
├───────────────────────────────────────────┤
│                                           │
│ Note *                                    │
│ ┌─────────────────────────────────┐      │
│ │ Base44 Apiryon App              │  ← כתוב
│ └─────────────────────────────────┘      │
│                                           │
│ Expiration *                              │
│ ┌─────────────────────────────────┐      │
│ │ 90 days                ▾        │  ← בחר
│ └─────────────────────────────────┘      │
│                                           │
│ Select scopes                             │
│                                           │
│ ☑️  repo                                  │  ← סמן!
│   ☑️  repo:status                         │
│   ☑️  repo_deployment                     │
│   ☑️  public_repo                         │
│   ☑️  repo:invite                         │
│   ☑️  security_events                     │
│                                           │
│ ☐ workflow                                │  ← אל תסמן
│ ☐ write:packages                          │  ← אל תסמן
│ ... (שאר התיבות - אל תסמן)               │
│                                           │
│ [ Generate token ]                        │  ← לחץ
└───────────────────────────────────────────┘
```

**חשוב**: סמן **רק** את `repo` - זה יסמן אוטומטי את כל התת-תיבות!

---

### שלב 3: GitHub יראה לך את ה-Token

```
┌───────────────────────────────────────────────┐
│ ✅ Personal access token created             │
├───────────────────────────────────────────────┤
│                                               │
│ Make sure to copy your personal access       │
│ token now. You won't be able to see it       │
│ again!                                        │
│                                               │
│ ┌─────────────────────────────────────────┐  │
│ │ ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxx      📋 │  │
│ └─────────────────────────────────────────┘  │
│                                               │
│ ⚠️  Copy this token NOW!                     │
│    You won't see it again!                   │
└───────────────────────────────────────────────┘
```

**לחץ על 📋** או סמן את כל הטקסט והעתק (Ctrl+C / Cmd+C)

---

### שלב 4: שמור את ה-Token

**אפשרויות:**
1. פתח Notepad/TextEdit ושמור בקובץ
2. שמור במנהל סיסמאות (1Password, LastPass)
3. כתוב על נייר (לא מומלץ)

**⚠️ אזהרה**: ברגע שתסגור את הדף - לא תוכל לראות את זה שוב!

---

## 🎯 עכשיו - איך משתמשים בו?

### אופציה 1: הגדרה קבועה (מומלץ)

```bash
# במקום username:password משתמשים ב-username:token
git remote set-url origin https://amir9111:TOKEN@github.com/amir9111/apiryon-karaoke.git
```

**החלף `TOKEN` ב-token האמיתי!**

### אופציה 2: שימוש חד-פעמי

```bash
git push -u origin main
# יבקש username: amir9111
# יבקש password: <הדבק את ה-Token כאן>
```

---

## ✅ אחרי שיש לך Token - תגיד לי!

כתוב: **"יש לי Token"**

ואני אעזור לך להגדיר אותו ולהעלות את הקוד!

---

## 🆘 בעיות?

### "לא הצלחתי ליצור Token"
- תסביר איפה נתקעת
- תשלח צילום מסך

### "איבדתי את ה-Token"
- אין בעיה! צור אחד חדש
- מחק את הישן ב-GitHub Settings → Tokens

### "אין לי גישה ל-GitHub"
- נעלה את הקוד ישירות ל-Base44
- ראה: MANUAL_UPLOAD_BASE44.md

---

**אתה מוכן? יש לך את ה-Token? בואו נמשיך! 🚀**
