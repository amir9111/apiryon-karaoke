// Placeholder component - not in use
export default function UserNotRegisteredError() {
  return null;
}